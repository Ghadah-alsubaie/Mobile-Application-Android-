﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProDesign
{
    public partial class LogIn : Form
    {
        public LogIn()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton2.Checked)
            {
                Customer openform1 = new Customer();
                openform1.Show();
                Visible = false;
            }
            else if (radioButton1.Checked)
            {
                Admin openform2 = new Admin();
                openform2.Show();
                Visible = false;
            }
            else
                MessageBox.Show("Please choose type of login", "make choice ",MessageBoxButtons.OK);
        }
    }
}
