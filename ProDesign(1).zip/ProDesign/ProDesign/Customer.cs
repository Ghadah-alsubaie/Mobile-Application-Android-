﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProDesign
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            LogIn openf = new LogIn();
            openf.Show();
            Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            Cart cart = new Cart();
            cart.Show();
            Visible=false;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            Search search = new Search();   
            search.Show();
            Visible = false;
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.Show();
            Visible = false;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            Payment payment = new Payment();
            payment.Show();
            Visible = false;
        }
    }
}
